#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

#define READ_END 0      //0为读端
#define WRITE_END 1     //1为写端

void primes(int input)
{
    int prime;
    if (read(input, &prime, 4) == 0){
        exit(0);
    }
    printf("prime %d\n", prime);
    int p[2];
    pipe(p);
    if (fork() == 0){
        close(p[WRITE_END]);
        primes(p[READ_END]);
    }
    else{
        close(p[READ_END]);
        int n;
        while(1){
            if(read(input, &n, 4) == 0)
                break;
            if (n % prime != 0)
                write(p[WRITE_END], &n, 4);
        }
        close(input);
        close(p[WRITE_END]);
    }
    wait(0);
    exit(0);
}

int main(int argc, char *argv[])
{
    int p[2];
    pipe(p);
    if (fork() == 0){
        close(p[WRITE_END]);
        primes(p[READ_END]);
    }
    else{
       close(p[READ_END]);
        int i;
        for (i = 2; i <= 35; i++){
            write(p[WRITE_END], &i, 4);
        }
        close(p[WRITE_END]);
    }
    wait(0);
    exit(0);
}