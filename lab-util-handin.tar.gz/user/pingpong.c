#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

#define READ_END 0      //0为读端
#define WRITE_END 1     //1为写端

int main(int argc, char *argv[])
{
    int parent[2], child[2];
    char buf[20];
    pipe(child); 
    pipe(parent);
    int pid = fork();
    if(pid == 0){       //子进程
        close(parent[WRITE_END]);
        read(parent[READ_END], buf, 4);
        close(parent[READ_END]);
        printf("%d: received %s\n", getpid(), buf);
        write(child[WRITE_END], "pong", sizeof(buf));
        exit(0);
    }
    else{       //父进程
        close(parent[READ_END]);
        write(parent[WRITE_END], "ping",4);
        close(child[WRITE_END]);
        read(child[READ_END], buf, sizeof(buf));
        printf("%d: received %s\n", getpid(), buf);
        exit(0);
    }
}